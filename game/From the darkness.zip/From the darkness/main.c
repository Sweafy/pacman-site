#include <stdio.h>
#include "raylib.h"
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 800
#define CELL_SIZE 40
#define MAP_WIDTH (SCREEN_WIDTH / CELL_SIZE)
#define MAP_HEIGHT (SCREEN_HEIGHT / CELL_SIZE)

typedef struct {
    Vector2 position;
    int speed;
} Player;

typedef struct {
    Vector2 position;
    int active;
} Lamp;

typedef struct {
    Vector2 position;
    Vector2 direction;
    int speed;
} Enemy;

// Carte du jeu (0 = vide, 1 = mur, 2 = ampoule)
int map[MAP_HEIGHT][MAP_WIDTH] = {
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,0,0,1,0,0,0,1,0,0,2,0,1,0,0,0,1,0,0,1,1,0,0,0,1},
    {1,0,1,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,1,0,1},
    {1,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,1},
    {1,0,1,0,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,0,0,0,0,0,1},
    {1,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,1,1,0,1,0,1,1,0,1},
    {1,1,1,0,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,1,1,0,0,1},
    {1,2,1,0,1,1,1,1,1,1,1,0,1,0,0,1,0,1,0,1,1,0,0,1,1},
    {1,0,0,0,0,0,0,0,2,0,1,0,1,1,0,1,0,0,0,1,1,1,0,1,1},
    {1,0,1,1,1,1,1,0,1,0,1,0,0,1,0,1,1,1,0,1,0,1,0,0,1},
    {1,0,0,0,1,0,0,0,1,0,1,1,0,1,0,0,0,1,0,1,1,0,1,1,1},
    {1,1,1,0,1,0,1,1,1,0,0,0,0,1,1,0,1,1,0,1,1,0,1,1,1},
    {1,0,0,0,1,0,0,0,0,0,1,1,0,0,0,0,1,0,0,1,0,1,1,0,1},
    {1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
};

Player player = {{CELL_SIZE, CELL_SIZE}, 4};
Lamp lamps[5];
Enemy enemies[2];

float enemy1SpawnTime = 15.0f;  
float enemy2SpawnTime = 30.0f;  
float timeElapsed = 0.0f;

void InitLamps() {
    int index = 0;
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            if (map[y][x] == 2) {
                lamps[index].position = (Vector2){x * CELL_SIZE, y * CELL_SIZE};
                lamps[index].active = 1;
                index++;
            }
        }
    }
}

void InitEnemies() {
    enemies[0] = (Enemy){{CELL_SIZE * 10, CELL_SIZE * 8}, {1, 0}, 2};
    enemies[1] = (Enemy){{CELL_SIZE * 5, CELL_SIZE * 5}, {0, 1}, 2};
}

int CheckCollisionWithWalls(Vector2 pos) {
    int x = (int)(pos.x / CELL_SIZE);
    int y = (int)(pos.y / CELL_SIZE);
    // Vérification des limites de la carte
    if (x < 0 || x >= MAP_WIDTH || y < 0 || y >= MAP_HEIGHT) {
        return 1; // Collision avec les bords de la carte
    }
    return (map[y][x] == 1); // Vérification de la collision avec un mur
}

void MovePlayer() {
    Vector2 newPos = player.position;

    // ZQSD pour les touches directionnelles
    if (IsKeyDown(KEY_D)) newPos.x += player.speed;
    if (IsKeyDown(KEY_A)) newPos.x -= player.speed;
    if (IsKeyDown(KEY_W)) newPos.y -= player.speed;
    if (IsKeyDown(KEY_S)) newPos.y += player.speed;

    // Empêche le joueur de traverser les murs
    if (!CheckCollisionWithWalls(newPos)) {
        player.position = newPos;
    }

    // Vérifier si le joueur ramasse une ampoule
    for (int i = 0; i < 5; i++) {
        if (lamps[i].active && CheckCollisionPointRec(player.position, (Rectangle){lamps[i].position.x, lamps[i].position.y, CELL_SIZE, CELL_SIZE})) {
            lamps[i].active = 0;
        }
    }
}

void MoveEnemies() {
    for (int i = 0; i < 2; i++) {
        Vector2 newPos = {enemies[i].position.x + enemies[i].direction.x * enemies[i].speed,
                          enemies[i].position.y + enemies[i].direction.y * enemies[i].speed};

        if (!CheckCollisionWithWalls(newPos)) {
            enemies[i].position = newPos;
        } else {
            enemies[i].direction.x = -enemies[i].direction.x;
            enemies[i].direction.y = -enemies[i].direction.y;
        }
    }
}


void SpawnEnemies() {
    if (timeElapsed >= enemy1SpawnTime && enemies[0].position.x == 0) {
        // Ennemi 1 apparaît à l'angle opposé du joueur (coin supérieur droit)
        enemies[0].position = (Vector2){SCREEN_WIDTH - CELL_SIZE, 0};
    }
    if (timeElapsed >= enemy2SpawnTime && enemies[1].position.x == 0) {
        // Ennemi 2 apparaît dans l'angle le plus proche du joueur
        enemies[1].position = (Vector2){CELL_SIZE, SCREEN_HEIGHT - CELL_SIZE};
    }
}

void DrawMap() {
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            if (map[y][x] == 1) {
                DrawRectangle(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE, DARKGRAY);
            }
        }
    }
}

int main() {
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "From The Darkness");
    InitLamps();
    InitEnemies();

    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        timeElapsed += GetFrameTime();  // Calculer le temps écoulé

        MovePlayer();
        MoveEnemies();
        SpawnEnemies();

        BeginDrawing();
        ClearBackground(BLACK);

        DrawMap();
        for (int i = 0; i < 5; i++) {
            if (lamps[i].active) DrawCircle(lamps[i].position.x + 20, lamps[i].position.y + 20, 10, YELLOW);
        }
        DrawRectangle(player.position.x, player.position.y, CELL_SIZE, CELL_SIZE, GREEN);
        for (int i = 0; i < 2; i++) {
            DrawRectangle(enemies[i].position.x, enemies[i].position.y, CELL_SIZE, CELL_SIZE, RED);
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
